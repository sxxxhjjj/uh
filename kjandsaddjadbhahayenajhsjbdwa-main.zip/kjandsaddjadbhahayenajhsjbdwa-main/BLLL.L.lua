-- special dumped using larry dec/deobf (dsc.gg/larrydeobf)


local larry5 = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local larry69 = larry5:CreateWindow({
    LoadingTitle = "Loading...",
    LoadingSubtitle = "by DYHUB!",
    Name = "DYHUB | Basketball Legends",
    --[[Theme = {
        Shadow = Color3.fromRGB(5, 10, 20),
        SliderProgress = Color3.fromRGB(100, 150, 255),
        PlaceholderColor = Color3.fromRGB(140, 180, 255),
        InputStroke = Color3.fromRGB(70, 110, 190),
        ToggleDisabledStroke = Color3.fromRGB(60, 60, 60),
        InputBackground = Color3.fromRGB(15, 25, 45),
        ElementBackgroundHover = Color3.fromRGB(30, 45, 80),
        DropdownUnselected = Color3.fromRGB(20, 30, 55),
        SelectedTabTextColor = Color3.fromRGB(120, 170, 255),
        NotificationBackground = Color3.fromRGB(20, 30, 55),
        DropdownSelected = Color3.fromRGB(30, 45, 80),
        SecondaryElementStroke = Color3.fromRGB(50, 90, 160),
        Background = Color3.fromRGB(10, 15, 30),
        ToggleDisabledOuterStroke = Color3.fromRGB(40, 40, 40),
        TabStroke = Color3.fromRGB(50, 70, 120),
        ElementBackground = Color3.fromRGB(20, 30, 55),
        ToggleEnabledOuterStroke = Color3.fromRGB(50, 90, 160),
        ToggleEnabled = Color3.fromRGB(100, 150, 255),
        ToggleEnabledStroke = Color3.fromRGB(70, 120, 200),
        ToggleDisabled = Color3.fromRGB(90, 90, 90),
        SecondaryElementBackground = Color3.fromRGB(15, 25, 45),
        ToggleBackground = Color3.fromRGB(20, 25, 45),
        TabTextColor = Color3.fromRGB(170, 200, 255),
        ElementStroke = Color3.fromRGB(70, 110, 180),
        SliderBackground = Color3.fromRGB(40, 70, 120),
        SliderStroke = Color3.fromRGB(70, 120, 200),
        NotificationActionsBackground = Color3.fromRGB(35, 50, 80),
        Topbar = Color3.fromRGB(15, 25, 45),
        TabBackground = Color3.fromRGB(40, 60, 100),
        TabBackgroundSelected = Color3.fromRGB(25, 40, 80),
        TextColor = Color3.fromRGB(170, 200, 255),
        ]]
    Theme = "Dark Blue",
})
local larry71 = game:GetService("Players")
local larry73 = game:GetService("RunService")
local larry75 = game:GetService("UserInputService")
local larry77 = game:GetService("TweenService")
local larry79 = game:GetService("Lighting")
local larry80 = larry71.LocalPlayer
local larry81 = larry80.Character
local larry85 = larry81:WaitForChild("HumanoidRootPart")
local larry86 = workspace.CurrentCamera
local _ = larry75.TouchEnabled
local _ = larry75.MouseEnabled
local larry90 = larry69:CreateTab("Ball Mods", nil)
larry90:CreateSection("Auto Green")
larry90:CreateLabel("It will say Callback Error but 100% works!", nil)
larry90:CreateToggle({
    CurrentValue = false,
    Callback = function(larry97, _97_2, _97_3, _97_4, _97_5, _97_6)
        larry5.Flags.AutoGood:Set(false)
        larry5.Flags.AutoGreat:Set(false)
        larry5.Flags.Randomizer:Set(false)
        larry73.RenderStepped:Connect(function(larry113)
            local _ = larry80.PlayerGui.Visual.Shooting.Visible
        end)
    end,
    Name = "Auto Perfect",
    Flag = "AutoPerfect",
})
larry90:CreateToggle({
    CurrentValue = false,
    Callback = function(larry120, _120_2, _120_3, _120_4)
        larry5.Flags.AutoPerfect:Set(false)
        larry5.Flags.AutoGreat:Set(false)
        larry5.Flags.Randomizer:Set(false)
        larry112:Disconnect()
        larry73.RenderStepped:Connect(function(larry138)
            local _ = larry80.PlayerGui.Visual.Shooting.Visible
        end)
    end,
    Name = "Auto Good",
    Flag = "AutoGood",
})
larry90:CreateToggle({
    CurrentValue = false,
    Callback = function(larry145, _145_2, _145_3)
        larry5.Flags.AutoPerfect:Set(false)
        larry5.Flags.AutoGood:Set(false)
        larry5.Flags.Randomizer:Set(false)
        larry137:Disconnect()
        larry73.RenderStepped:Connect(function(larry163)
            local _ = larry80.PlayerGui.Visual.Shooting.Visible
        end)
    end,
    Name = "Auto Great",
    Flag = "AutoGreat",
})
larry90:CreateToggle({
    CurrentValue = false,
    Callback = function(larry170, _170_2, _170_3, _170_4, _170_5, _170_6)
        larry5.Flags.AutoPerfect:Set(false)
        larry5.Flags.AutoGood:Set(false)
        larry5.Flags.AutoGreat:Set(false)
        larry162:Disconnect()
        larry73.RenderStepped:Connect(function(larry188)
            local _ = larry80.PlayerGui.Visual.Shooting.Visible
        end)
    end,
    Name = "Randomizer",
    Flag = "Randomizer",
})
larry90:CreateSlider({
    Callback = function(larry195, _195_2)
    end,
    Name = "Good Value",
    Suffix = "value",
    CurrentValue = 0.9,
    Increment = 0.01,
    Range = {
        [1] = 0.1,
        [2] = 1,
    },
    Flag = "GoodValue",
})
larry90:CreateSlider({
    Callback = function(larry198)
    end,
    Name = "Great Value",
    Suffix = "value",
    CurrentValue = 0.95,
    Increment = 0.01,
    Range = {
        [1] = 0.1,
        [2] = 1,
    },
    Flag = "GreatValue",
})
larry90:CreateSection("Ball Magnet")
larry90:CreateButton({
    Name = "Ball Magnet Script",
    Callback = function(larry203, _203_2)
        loadstring(game:HttpGet("https://pastebin.com/raw/kcYYUzPg"))()
    end,
})
larry90:CreateToggle({
    CurrentValue = false,
    Callback = function(larry210, _210_2, _210_3, _210_4, _210_5)
        larry73.Heartbeat:Connect(function(larry214)
            for larry217, _217_2 in pairs(workspace:GetDescendants()) do
                local _ = _217_2.Name
            end
        end)
    end,
    Name = "Ball Magnet",
    Flag = "BallMagEnabled",
})
larry90:CreateSlider({
    Callback = function(larry221, _221_2, _221_3, _221_4, _221_5)
    end,
    Name = "Ball Magnet Range",
    Suffix = "studs",
    CurrentValue = 10,
    Increment = 1,
    Range = {
        [1] = 1,
        [2] = 10,
    },
    Flag = "BallMagRange",
})
larry90:CreateSection("Auto Guard")
larry90:CreateToggle({
    CurrentValue = false,
    Callback = function(larry226, _226_2, _226_3, _226_4)
        larry73.Heartbeat:Connect(function(larry230, _230_2)
            for larry233, _233_2 in pairs(larry71:GetPlayers()) do
                local _ = _233_2 == larry80
                local larry235 = _233_2.Character
                larry235:FindFirstChild("Basketball")
                local _ = larry80.Team == _233_2.Team
                local larry243 = larry235:FindFirstChild("HumanoidRootPart").Position
                larry85.CFrame = CFrame.lookAt(larry85.Position, Vector3.new(larry243.X, larry85.Position.Y, larry243.Z))
                game:GetService("VirtualInputManager"):SendKeyEvent(true, Enum.KeyCode.F, false, game)
            end
        end)
    end,
    Name = "Auto Guard",
    Flag = "AutoGuard",
})
larry90:CreateLabel("This will auto face the character to the person that has the ball, so this makes it easier for you to Block & Guard!")
larry90:CreateDivider()
larry90:CreateSection("Auto Get Rebound")
larry90:CreateToggle({
    CurrentValue = false,
    Callback = function(larry267, _267_2, _267_3, _267_4, _267_5)
        larry73.Heartbeat:Connect(function(larry271, _271_2, _271_3, _271_4, _271_5)
            for larry274, _274_2 in pairs(workspace:GetDescendants()) do
                local _ = _274_2.Name
            end
        end)
    end,
    Name = "Auto Get Rebound",
    Flag = "AutoGetBall",
})
larry90:CreateLabel("100% auto gets the basketball if it exists and isn't in anyone hands!")
larry90:CreateSection("Auto Steal")
larry90:CreateButton({
    Name = "Auto Steal",
    Callback = function(larry282, _282_2, _282_3, _282_4)
        loadstring(game:HttpGet("https://pastefy.app/xISFifA3/raw"))()
    end,
})
larry90:CreateLabel("Has NOT been tested but it should work!")
local larry290 = larry69:CreateTab("Player Configuration", nil)
larry290:CreateSection("Speed Boost")
larry290:CreateToggle({
    CurrentValue = false,
    Callback = function(larry295)
        larry73.RenderStepped:Connect(function(larry299, _299_2, _299_3, _299_4, _299_5)
            larry81:FindFirstChild("HumanoidRootPart")
            local _ = larry81:WaitForChild("Humanoid").MoveDirection.Magnitude
            error("line 1: attempt to compare number < table")
        end)
    end,
    Name = "Speed Boost",
    Flag = "SpeedEnabled",
})
larry290:CreateSlider({
    Callback = function(larry306, _306_2)
    end,
    Name = "Speed Value",
    Suffix = "x",
    CurrentValue = 1,
    Increment = 0.1,
    Range = {
        [1] = 0.1,
        [2] = 2,
    },
    Flag = "SpeedValue",
})
larry290:CreateSection("Mobile Teleports")
larry290:CreateToggle({
    CurrentValue = false,
    Callback = function(larry311, _311_2, _311_3)
        local larry313 = larry80:WaitForChild("PlayerGui")
        larry313:FindFirstChild("TpButton")
        larry313.TpButton:Destroy()
        local larry320 = Instance.new("ScreenGui")
        larry320.Name = "TpButton"
        larry320.Parent = larry313
        local larry322 = Instance.new("TextButton")
        larry322.Name = "Btn"
        larry322.Size = UDim2.new(0, 200, 0, 50)
        larry322.Position = UDim2.new(0.5, - 100, 0.9, - 25)
        larry322.AnchorPoint = Vector2.new(0.5, 0.5)
        larry322.BackgroundTransparency = 1
        larry322.Text = ""
        larry322.Parent = larry320
        local larry330 = Instance.new("Frame")
        larry330.Name = "Bg"
        larry330.Size = UDim2.new(1, 0, 1, 0)
        larry330.BackgroundColor3 = Color3.new(1, 1, 1)
        larry330.Parent = larry322
        local larry336 = Instance.new("UIGradient")
        larry336.Rotation = 90
        local larry346 = ColorSequence.new({
            [1] = ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 100, 255)),
            [2] = ColorSequenceKeypoint.new(1, Color3.fromRGB(150, 0, 255)),
        })
        larry336.Color = larry346
        larry336.Parent = larry330
        local larry348 = Instance.new("UICorner")
        larry348.CornerRadius = UDim.new(0, 12)
        larry348.Parent = larry330
        local larry352 = Instance.new("UIStroke")
        larry352.Color = Color3.fromRGB(60, 60, 60)
        larry352.Thickness = 2
        larry352.Parent = larry330
        local larry356 = Instance.new("TextLabel")
        larry356.Size = UDim2.new(1, 0, 1, 0)
        larry356.BackgroundTransparency = 1
        larry356.Text = "Quick Tp"
        larry356.Font = Enum.Font.GothamBold
        larry356.TextColor3 = Color3.new(1, 1, 1)
        larry356.TextSize = 20
        larry356.Parent = larry322
        local larry364 = Instance.new("UIStroke")
        larry364.Color = Color3.new(0, 0, 0)
        larry364.Thickness = 1.5
        larry364.Parent = larry356
        local larry368 = larry336:Clone()
        local larry378 = ColorSequence.new({
            [1] = ColorSequenceKeypoint.new(0, Color3.fromRGB(50, 150, 255)),
            [2] = ColorSequenceKeypoint.new(1, Color3.fromRGB(180, 50, 255)),
        })
        larry368.Color = larry378
        larry322.MouseEnter:Connect(function(larry382, _382_2)
            local larry387 = larry77:Create(larry336, TweenInfo.new(0.2), {
                Color = larry368.Color,
            })
            larry387:Play()
            local larry393 = larry77:Create(larry352, TweenInfo.new(0.2), {
                Thickness = 3,
            })
            larry393:Play()
        end)
        larry322.MouseLeave:Connect(function(larry399, _399_2, _399_3, _399_4)
            local larry412 = ColorSequence.new({
                [1] = ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 100, 255)),
                [2] = ColorSequenceKeypoint.new(1, Color3.fromRGB(150, 0, 255)),
            })
            local larry413 = larry77:Create(larry336, TweenInfo.new(0.3), {
                Color = larry412,
            })
            larry413:Play()
            local larry419 = larry77:Create(larry352, TweenInfo.new(0.3), {
                Thickness = 2,
            })
            larry419:Play()
        end)
        larry322.MouseButton1Click:Connect(function()
            local larry428 = game.Players.LocalPlayer.Character
            larry428:FindFirstChild("HumanoidRootPart")
            local _ = larry428:FindFirstChildOfClass("Humanoid").MoveDirection.Magnitude
            error("line 1: attempt to compare number < table")
        end)
    end,
    Name = "Quick TP",
    Flag = "QuickTpEnabled",
})
larry290:CreateSlider({
    Callback = function(larry437, _437_2, _437_3, _437_4, _437_5, _437_6)
    end,
    Name = "Quick TP Distance",
    Suffix = "studs",
    CurrentValue = 2.5,
    Increment = 0.1,
    Range = {
        [1] = 0.1,
        [2] = 5,
    },
    Flag = "QuickTpDist",
})
larry290:CreateSlider({
    Callback = function(larry440, _440_2, _440_3, _440_4, _440_5)
    end,
    Name = "Quick TP Delay",
    Suffix = "seconds",
    CurrentValue = 0.3,
    Increment = 0.1,
    Range = {
        [1] = 0.1,
        [2] = 1,
    },
    Flag = "QuickTpDelay",
})
larry290:CreateSection("Computer Teleports")
larry290:CreateToggle({
    CurrentValue = false,
    Callback = function(larry445, _445_2, _445_3, _445_4, _445_5)
    end,
    Name = "R to TP",
    Flag = "RToTpEnabled",
})
larry290:CreateSlider({
    Callback = function(larry448, _448_2, _448_3, _448_4)
    end,
    Name = "R TP Distance",
    Suffix = "studs",
    CurrentValue = 2.5,
    Increment = 0.1,
    Range = {
        [1] = 0.1,
        [2] = 3,
    },
    Flag = "RToTpDist",
})
larry290:CreateSlider({
    Callback = function(larry451, _451_2, _451_3, _451_4, _451_5)
    end,
    Name = "R TP Delay",
    Suffix = "seconds",
    CurrentValue = 0.3,
    Increment = 0.1,
    Range = {
        [1] = 0.1,
        [2] = 1,
    },
    Flag = "RToTpDelay",
})
larry290:CreateLabel("Click R to teleport if you are in a Computer!")
local larry455 = larry69:CreateTab("ESP Features", nil)
larry455:CreateSection("Tracers")
larry455:CreateToggle({
    CurrentValue = false,
    Callback = function(larry460, _460_2, _460_3)
        for larry463, _463_2 in pairs(larry71:GetPlayers()) do
            local _ = _463_2 == larry80
            local _ = _463_2.Character
            local larry467 = Drawing.new("Line")
            larry467.Visible = false
            larry467.Color = Color3.new(1, 0, 0)
            larry467.Thickness = 2
            larry467.ZIndex = 1
        end
        larry73.RenderStepped:Connect(function(larry473, _473_2)
            larry71:FindFirstChild(_463_2.Name)
            local _ = _463_2.Character
            _463_2.Character:FindFirstChild("HumanoidRootPart")
            larry86:WorldToViewportPoint(_463_2.Character.HumanoidRootPart.Position)
            larry467.Visible = false
        end)
    end,
    Name = "Tracer ESP",
    Flag = "TracerEnabled",
})
larry455:CreateSection("Basketball ESP")
larry455:CreateToggle({
    CurrentValue = false,
    Callback = function(larry490)
        larry472:Disconnect()
        larry467:Remove()
        for larry497, _497_2 in pairs(larry71:GetPlayers()) do
            local _ = _497_2 == larry80
            local _ = _497_2.Character
            local larry501 = Drawing.new("Line")
            larry501.Visible = false
            larry501.Color = Color3.new(1, 0, 0)
            larry501.Thickness = 2
            larry501.ZIndex = 1
        end
        larry73.RenderStepped:Connect(function(larry507, _507_2)
            larry71:FindFirstChild(_497_2.Name)
            local _ = _497_2.Character
            _497_2.Character:FindFirstChild("HumanoidRootPart")
            larry86:WorldToViewportPoint(_497_2.Character.HumanoidRootPart.Position)
            larry501.Visible = false
            for larry522, _522_2 in pairs(workspace:GetDescendants()) do
                local _ = _522_2.Name
            end
        end)
    end,
    Name = "Basketball Highlight",
    Flag = "BasketballHighlight",
})
larry455:CreateSection("Player ESP")
larry455:CreateToggle({
    CurrentValue = false,
    Callback = function(larry528, _528_2, _528_3, _528_4)
        larry506:Disconnect()
        larry501:Remove()
        for larry535, _535_2 in pairs(larry71:GetPlayers()) do
            local _ = _535_2 == larry80
            local _ = _535_2.Character
            local larry539 = Drawing.new("Line")
            larry539.Visible = false
            larry539.Color = Color3.new(1, 0, 0)
            larry539.Thickness = 2
            larry539.ZIndex = 1
        end
        larry73.RenderStepped:Connect(function(larry545, _545_2)
            larry71:FindFirstChild(_535_2.Name)
            local _ = _535_2.Character
            _535_2.Character:FindFirstChild("HumanoidRootPart")
            larry86:WorldToViewportPoint(_535_2.Character.HumanoidRootPart.Position)
            larry539.Visible = false
            for larry560, _560_2 in pairs(workspace:GetDescendants()) do
                local _ = _560_2.Name
            end
            for larry564, _564_2 in pairs(larry71:GetPlayers()) do
                local _ = _564_2 == larry80
                local _ = _564_2.Character
                local _ = _564_2.Character
                local larry569 = Instance.new("Highlight")
                larry569.Name = "PlayerESP"
                larry569.FillColor = Color3.new(0, 1, 0)
                larry569.OutlineColor = Color3.new(0, 0, 1)
                larry569.FillTransparency = 0.7
                larry569.OutlineTransparency = 0
                larry569.Parent = _564_2.Character
            end
        end)
    end,
    Name = "Player ESP",
    Flag = "PlayerESP",
})
local larry576 = larry69:CreateTab("World Changer", nil)
larry576:CreateSection("FOV Modifier")
larry576:CreateToggle({
    CurrentValue = false,
    Callback = function(larry581, _581_2)
        larry73.RenderStepped:Connect(function(larry585, _585_2, _585_3, _585_4)
            larry86.FieldOfView = 90
        end)
        larry86.FieldOfView = 90
    end,
    Name = "FOV Modifier",
    Flag = "FOVEnabled",
})
larry576:CreateSlider({
    Callback = function(larry588, _588_2)
        larry86.FieldOfView = larry588
    end,
    Name = "FOV Value",
    Suffix = "FOV",
    CurrentValue = 90,
    Increment = 1,
    Range = {
        [1] = 60,
        [2] = 120,
    },
    Flag = "FOVValue",
})
larry576:CreateSection("Camera Resolution")
larry576:CreateToggle({
    CurrentValue = false,
    Callback = function(larry593, _593_2, _593_3, _593_4, _593_5, _593_6)
        larry73.RenderStepped:Connect(function()
            larry86.CFrame = (larry86.CFrame * CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.8, 0, 0, 0, 1))
        end)
    end,
    Name = "Camera Resolution Toggle",
    Flag = "CameraResEnabled",
})
larry576:CreateSlider({
    Callback = function(larry604, _604_2, _604_3, _604_4, _604_5, _604_6)
    end,
    Name = "Camera Resolution",
    Suffix = "quality",
    CurrentValue = 0.8,
    Increment = 0.05,
    Range = {
        [1] = 0.3,
        [2] = 1,
    },
    Flag = "CameraResValue",
})
larry576:CreateSection("Extra Stuff")
larry576:CreateToggle({
    CurrentValue = false,
    Callback = function(larry609, _609_2, _609_3, _609_4, _609_5)
        larry79.Ambient = Color3.new(0.8, 0.8, 0.8)
        larry79.Brightness = 1.5
        larry79.GlobalShadows = false
        larry79.OutdoorAmbient = Color3.new(0.8, 0.8, 0.8)
    end,
    Name = "Full Bright",
    Flag = "FullBright",
})
larry576:CreateToggle({
    CurrentValue = false,
    Callback = function(larry616, _616_2, _616_3, _616_4, _616_5)
        larry79.FogEnd = 1000000
        larry79.FogStart = 1000000
    end,
    Name = "No Fog",
    Flag = "NoFog",
})
larry576:CreateToggle({
    CurrentValue = false,
    Callback = function(larry619, _619_2)
        for larry622, _622_2 in pairs(larry79:GetChildren()) do
            _622_2:IsA("PostEffect")
            _622_2:Destroy()
        end
        local larry628 = Instance.new("BloomEffect")
        larry628.Name = "NVIDIABloom"
        larry628.Intensity = 0.2
        larry628.Size = 16
        larry628.Threshold = 0.9
        larry628.Parent = larry79
        local larry630 = Instance.new("ColorCorrectionEffect")
        larry630.Name = "NVIDIAColor"
        larry630.Brightness = 0.02
        larry630.Contrast = 0.1
        larry630.Saturation = 0.1
        larry630.TintColor = Color3.new(1.01, 1.005, 0.995)
        larry630.Parent = larry79
        local larry634 = Instance.new("DepthOfFieldEffect")
        larry634.Name = "NVIDIADepth"
        larry634.FarIntensity = 0.02
        larry634.FocusDistance = 25
        larry634.InFocusRadius = 40
        larry634.NearIntensity = 0.1
        larry634.Parent = larry79
        local larry636 = Instance.new("SunRaysEffect")
        larry636.Name = "NVIDIASunRays"
        larry636.Intensity = 0.1
        larry636.Spread = 0.4
        larry636.Parent = larry79
        local larry638 = Instance.new("BlurEffect")
        larry638.Name = "NVIDIABlur"
        larry638.Size = 0.2
        larry638.Parent = larry79
        larry79.GlobalShadows = true
        larry79.ShadowSoftness = 0.4
        larry79.Brightness = 1.05
        larry79.OutdoorAmbient = Color3.new(0.6, 0.7, 0.9)
        larry79.Ambient = Color3.new(0.45, 0.45, 0.55)
        larry79.ColorShift_Bottom = Color3.new(0.02, 0.02, 0.05)
        larry79.ColorShift_Top = Color3.new(0.8, 0.7, 0.6)
        larry79.FogColor = Color3.new(0.4, 0.5, 0.7)
        larry79.FogStart = 100
        larry79.FogEnd = 500
        for larry651, _651_2 in pairs(workspace:GetDescendants()) do
            _651_2:IsA("Part")
            local _ = _651_2.Material == Enum.Material.Plastic
            local _ = _651_2.Material == Enum.Material.Wood
        end
    end,
    Name = "NVIDIA Style Shaders",
    Flag = "Shaders",
})
larry75.InputBegan:Connect(function(larry665, _665_2, _665_3, _665_4, _665_5, _665_6)
    local _ = larry665.UserInputType == Enum.UserInputType.MouseButton1
    local _ = larry665.KeyCode == Enum.KeyCode.Space
end)
larry80.CharacterAdded:Connect(function(larry677, _677_2, _677_3, _677_4, _677_5, _677_6)
    local larry679 = larry677:WaitForChild("Humanoid")
    local larry681 = larry677:WaitForChild("HumanoidRootPart")
    larry298:Disconnect()
    larry73.RenderStepped:Connect(function(larry687, _687_2, _687_3, _687_4, _687_5)
        larry677:FindFirstChild("HumanoidRootPart")
        local _ = larry679.MoveDirection.Magnitude
        error("line 1: attempt to compare number < table")
    end)
    larry213:Disconnect()
    larry73.Heartbeat:Connect(function(larry697)
        for larry700, _700_2 in pairs(workspace:GetDescendants()) do
            local _ = _700_2.Name
        end
    end)
    larry584:Disconnect()
    larry73.RenderStepped:Connect(function(larry707, _707_2, _707_3, _707_4)
        larry86.FieldOfView = larry588
    end)
    larry596:Disconnect()
    larry73.RenderStepped:Connect(function()
        larry86.CFrame = (larry86.CFrame * CFrame.new(0, 0, 0, 1, 0, 0, 0, larry604, 0, 0, 0, 1))
    end)
    larry229:Disconnect()
    game:GetService("VirtualInputManager"):SendKeyEvent(false, Enum.KeyCode.F, false, game)
    larry73.Heartbeat:Connect(function(larry729, _729_2)
        for larry732, _732_2 in pairs(larry71:GetPlayers()) do
            local _ = _732_2 == larry80
            local larry734 = _732_2.Character
            larry734:FindFirstChild("Basketball")
            local _ = larry80.Team == _732_2.Team
            local larry742 = larry734:FindFirstChild("HumanoidRootPart").Position
            larry681.CFrame = CFrame.lookAt(larry681.Position, Vector3.new(larry742.X, larry681.Position.Y, larry742.Z))
            game:GetService("VirtualInputManager"):SendKeyEvent(true, Enum.KeyCode.F, false, game)
        end
    end)
    larry270:Disconnect()
    larry73.Heartbeat:Connect(function(larry763, _763_2, _763_3, _763_4, _763_5)
        for larry766, _766_2 in pairs(workspace:GetDescendants()) do
            local _ = _766_2.Name
        end
    end)
    larry544:Disconnect()
    larry569:Destroy()
    larry539:Remove()
    for larry776, _776_2 in pairs(larry71:GetPlayers()) do
        local _ = _776_2 == larry80
        local _ = _776_2.Character
        local larry780 = Drawing.new("Line")
        larry780.Visible = false
        larry780.Color = Color3.new(1, 0, 0)
        larry780.Thickness = 2
        larry780.ZIndex = 1
    end
    larry73.RenderStepped:Connect(function(larry786, _786_2)
        larry71:FindFirstChild(_776_2.Name)
        local _ = _776_2.Character
        _776_2.Character:FindFirstChild("HumanoidRootPart")
        larry86:WorldToViewportPoint(_776_2.Character.HumanoidRootPart.Position)
        larry780.Visible = false
        for larry801, _801_2 in pairs(workspace:GetDescendants()) do
            local _ = _801_2.Name
        end
        for larry805, _805_2 in pairs(larry71:GetPlayers()) do
            local _ = _805_2 == larry80
            local _ = _805_2.Character
            local _ = _805_2.Character
            local larry810 = Instance.new("Highlight")
            larry810.Name = "PlayerESP"
            larry810.FillColor = Color3.new(0, 1, 0)
            larry810.OutlineColor = Color3.new(0, 0, 1)
            larry810.FillTransparency = 0.7
            larry810.OutlineTransparency = 0
            larry810.Parent = _805_2.Character
        end
    end)
    larry187:Disconnect()
    larry73.RenderStepped:Connect(function(larry821)
        local _ = larry80.PlayerGui.Visual.Shooting.Visible
    end)
end)
larry71.PlayerAdded:Connect(function(larry829, _829_2, _829_3, _829_4, _829_5, _829_6)
    local _ = larry829.Character
    local larry832 = Drawing.new("Line")
    larry832.Visible = false
    larry832.Color = Color3.new(1, 0, 0)
    larry832.Thickness = 2
    larry832.ZIndex = 1
end)
larry686:Disconnect()
larry73.RenderStepped:Connect(function(larry840, _840_2, _840_3, _840_4, _840_5)
    larry677:FindFirstChild("HumanoidRootPart")
    local _ = larry679.MoveDirection.Magnitude
    error("line 1: attempt to compare number < table")
end)
larry696:Disconnect()
larry73.Heartbeat:Connect(function(larry850)
    for larry853, _853_2 in pairs(workspace:GetDescendants()) do
        local _ = _853_2.Name
    end
end)
larry706:Disconnect()
larry73.RenderStepped:Connect(function(larry860, _860_2, _860_3, _860_4)
    larry86.FieldOfView = larry588
end)
larry712:Disconnect()
larry73.RenderStepped:Connect(function()
    larry86.CFrame = (larry86.CFrame * CFrame.new(0, 0, 0, 1, 0, 0, 0, larry604, 0, 0, 0, 1))
end)
larry728:Disconnect()
game:GetService("VirtualInputManager"):SendKeyEvent(false, Enum.KeyCode.F, false, game)
larry73.Heartbeat:Connect(function(larry882, _882_2)
    for larry885, _885_2 in pairs(larry71:GetPlayers()) do
        local _ = _885_2 == larry80
        local larry887 = _885_2.Character
        larry887:FindFirstChild("Basketball")
        local _ = larry80.Team == _885_2.Team
        local larry895 = larry887:FindFirstChild("HumanoidRootPart").Position
        larry681.CFrame = CFrame.lookAt(larry681.Position, Vector3.new(larry895.X, larry681.Position.Y, larry895.Z))
        game:GetService("VirtualInputManager"):SendKeyEvent(true, Enum.KeyCode.F, false, game)
    end
end)
larry762:Disconnect()
larry73.Heartbeat:Connect(function(larry916, _916_2, _916_3, _916_4, _916_5)
    for larry919, _919_2 in pairs(workspace:GetDescendants()) do
        local _ = _919_2.Name
    end
end)
larry785:Disconnect()
larry780:Remove()
larry832:Remove()
larry810:Destroy()
for larry931, _931_2 in pairs(larry71:GetPlayers()) do
    local _ = _931_2 == larry80
    local _ = _931_2.Character
    local larry935 = Drawing.new("Line")
    larry935.Visible = false
    larry935.Color = Color3.new(1, 0, 0)
    larry935.Thickness = 2
    larry935.ZIndex = 1
end
larry73.RenderStepped:Connect(function(larry941, _941_2)
    larry71:FindFirstChild(_931_2.Name)
    local _ = _931_2.Character
    _931_2.Character:FindFirstChild("HumanoidRootPart")
    larry86:WorldToViewportPoint(_931_2.Character.HumanoidRootPart.Position)
    larry935.Visible = false
    for larry956, _956_2 in pairs(workspace:GetDescendants()) do
        local _ = _956_2.Name
    end
    for larry960, _960_2 in pairs(larry71:GetPlayers()) do
        local _ = _960_2 == larry80
        local _ = _960_2.Character
        local _ = _960_2.Character
        local larry965 = Instance.new("Highlight")
        larry965.Name = "PlayerESP"
        larry965.FillColor = Color3.new(0, 1, 0)
        larry965.OutlineColor = Color3.new(0, 0, 1)
        larry965.FillTransparency = 0.7
        larry965.OutlineTransparency = 0
        larry965.Parent = _960_2.Character
    end
end)
larry820:Disconnect()
larry73.RenderStepped:Connect(function(larry976)
    local _ = larry80.PlayerGui.Visual.Shooting.Visible
end)
larry79.Ambient = Color3.new(0.8, 0.8, 0.8)
larry79.Brightness = 1.5
larry79.GlobalShadows = false
larry79.OutdoorAmbient = Color3.new(0.8, 0.8, 0.8)
larry79.FogEnd = 1000000
larry79.FogStart = 1000000
for larry987, _987_2 in pairs(larry79:GetChildren()) do
    _987_2:IsA("PostEffect")
    _987_2:Destroy()
end
local larry993 = Instance.new("BloomEffect")
larry993.Name = "NVIDIABloom"
larry993.Intensity = 0.2
larry993.Size = 16
larry993.Threshold = 0.9
larry993.Parent = larry79
local larry995 = Instance.new("ColorCorrectionEffect")
larry995.Name = "NVIDIAColor"
larry995.Brightness = 0.02
larry995.Contrast = 0.1
larry995.Saturation = 0.1
larry995.TintColor = Color3.new(1.01, 1.005, 0.995)
larry995.Parent = larry79
local larry999 = Instance.new("DepthOfFieldEffect")
larry999.Name = "NVIDIADepth"
larry999.FarIntensity = 0.02
larry999.FocusDistance = 25
larry999.InFocusRadius = 40
larry999.NearIntensity = 0.1
larry999.Parent = larry79
local larry1001 = Instance.new("SunRaysEffect")
larry1001.Name = "NVIDIASunRays"
larry1001.Intensity = 0.1
larry1001.Spread = 0.4
larry1001.Parent = larry79
local larry1003 = Instance.new("BlurEffect")
larry1003.Name = "NVIDIABlur"
larry1003.Size = 0.2
larry1003.Parent = larry79
larry79.GlobalShadows = true
larry79.ShadowSoftness = 0.4
larry79.Brightness = 1.05
larry79.OutdoorAmbient = Color3.new(0.6, 0.7, 0.9)
larry79.Ambient = Color3.new(0.45, 0.45, 0.55)
larry79.ColorShift_Bottom = Color3.new(0.02, 0.02, 0.05)
larry79.ColorShift_Top = Color3.new(0.8, 0.7, 0.6)
larry79.FogColor = Color3.new(0.4, 0.5, 0.7)
larry79.FogStart = 100
larry79.FogEnd = 500
for larry1016, _1016_2 in pairs(workspace:GetDescendants()) do
    _1016_2:IsA("Part")
    local _ = _1016_2.Material == Enum.Material.Plastic
    local _ = _1016_2.Material == Enum.Material.Wood
end
larry5:LoadConfiguration()
