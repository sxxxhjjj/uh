-- ======================
local version = "2.5.8"
-- ======================
repeat task.wait() until game:IsLoaded()
-- FPS Unlock
if setfpscap then
    setfpscap(1000000)
    game:GetService("StarterGui"):SetCore("SendNotification", {
        Title = "dsc.gg/dyhub",
        Text = "FPS Unlocked!",
        Duration = 2,
        Button1 = "Okay"
    })
    warn("FPS Unlocked!")
else
    game:GetService("StarterGui"):SetCore("SendNotification", {
        Title = "dsc.gg/dyhub",
        Text = "Your exploit does not support setfpscap.",
        Duration = 2,
        Button1 = "Okay"
    })
    warn("Your exploit does not support setfpscap.")
end
local WindUI = loadstring(game:HttpGet("https://github.com/Footagesus/WindUI/releases/latest/download/main.lua"))()
local executorName = "Unknown"
pcall(function()
    -- Primary executor detection from identifyexecutor()
    if identifyexecutor then
        local name, ver = identifyexecutor()
        executorName = ver and (name .. " (" .. ver .. ")") or name
        return
    end
    -- Fallback to getexecutorname()
    if getexecutorname then
        executorName = getexecutorname()
        return
    end
    -- Check global flags for popular executors
    local globals = getgenv and getgenv() or _G
    local checkList = {
        { "Delta", "Delta" },
        { "Xeno", "Xeno" },
        { "Zenith", "Zenith" },
        { "Wave", "Wave" },
        { "Volt", "Volt" },
        { "Volcano", "Volcano" },
        { "Velocity", "Velocity" },
        { "Seliware", "Seliware" },
        { "Valex", "Valex" },
        { "Potassium", "Potassium" },
        { "Bunni", "Bunni" },
        { "Sirhurt", "Sirhurt" },
        { "Codex", "Codex" },
        { "Solara", "Solara" },
        { "Cryptic", "Cryptic" },
        { "Krnl", "Krnl" },
    }
    for _, data in ipairs(checkList) do
        local key, name = unpack(data)
        if globals[key] ~= nil or (pcall(function() return getfenv and getfenv()[key] end) and getfenv and getfenv()[key] ~= nil) then
            executorName = name
            return
        end
    end
    -- Check Lua environment source for some executors
    local info = debug.getinfo(1, "S")
    if info and info.source then
        local src = string.lower(info.source)
        if src:find("synapse") then executorName = "Synapse Z" end
        if src:find("fluxus") then executorName = "Fluxus" end
        if src:find("krnl") then executorName = "Krnl" end
        if src:find("delta") then executorName = "Delta" end
    end
end)
-- Notify via WindUI
WindUI:Notify({
    Title = "DYHUB",
    Content = "Executor: " .. executorName .. ".",
    Duration = 6,
    Image = "cpu"
})
-- ====================== WINDOW ======================
local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local FreeVersion = "Free Version"
local PremiumVersion = "Premium Version"
local function checkVersion(playerName)
    local url = "https://raw.githubusercontent.com/mabdu21/2askdkn21h3u21ddaa/refs/heads/main/Main/Premium/listpremium.lua"
    local success, response = pcall(function()
        return game:HttpGet(url)
    end)
    if not success then
        return FreeVersion
    end
    local premiumData
    local func, err = loadstring(response)
    if func then
        premiumData = func()
    else
        return FreeVersion
    end
    if premiumData[playerName] then
        return PremiumVersion
    else
        return FreeVersion
    end
end
local player = Players.LocalPlayer
local userversion = checkVersion(player.Name)
local Window = WindUI:CreateWindow({
    Title = "DYHUB",
    IconThemed = true,
    Icon = "rbxassetid://104487529937663",
    Author = "The Forge | " .. userversion .. " | v" .. version,
    Folder = "DYHUB_TF",
    Size = UDim2.fromOffset(550, 450), -- Slightly larger for premium feel
    Transparent = true,
    Theme = "Dark",
    BackgroundImageTransparency = 0.7,
    HasOutline = true,
    HideSearchBar = false,
    ScrollBarEnabled = true,
    User = { Enabled = true, Anonymous = false },
})
Window:SetToggleKey(Enum.KeyCode.K)
pcall(function()
    Window:Tag({
        Title = version,
        Color = Color3.fromHex("#30ff6a")
    })
end)
Window:EditOpenButton({
    Title = "DYHUB - Open",
    Icon = "monitor",
    CornerRadius = UDim.new(0, 8),
    StrokeThickness = 1.5,
    Color = ColorSequence.new(Color3.fromRGB(20, 20, 20), Color3.fromRGB(100, 255, 100)),
    Draggable = true,
})

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local MarketplaceService = game:GetService("MarketplaceService")
local Workspace = game:GetService("Workspace")
local LocalPlayer = Players.LocalPlayer
local KnitServices = ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Packages"):WaitForChild("Knit"):WaitForChild("Services")
local function GetServiceRemote(serviceName, remoteType, remoteName)
    local success, result = pcall(function()
        return KnitServices:WaitForChild(serviceName):WaitForChild("RF"):WaitForChild(remoteName)
    end)
    return success and result or nil
end
local Remotes = {
    RedeemCode = GetServiceRemote("CodeService", "RF", "RedeemCode"),
    ToolActivated = GetServiceRemote("ToolService", "RF", "ToolActivated"),
    StartBlock = GetServiceRemote("ToolService", "RF", "StartBlock"),
    StopBlock = GetServiceRemote("ToolService", "RF", "StopBlock"),
    Run = GetServiceRemote("CharacterService", "RF", "Run"),
    ChangeSequence = GetServiceRemote("ForgeService", "RF", "ChangeSequence"),
    StartForge = GetServiceRemote("ForgeService", "RF", "StartForge"),
    Forge = GetServiceRemote("ProximityService", "RF", "Forge"),
}
local Config = {
    AutoRun = false,
    AutoMine = false,
    MineTarget = "Pebble",
    AutoAttack = false,
    AutoParry = false,
    AttackTargets = {},
    ForgeItemType = "Weapon",
    InfiniteFly = false,
    FlySpeed = 50,
    ClickTeleport = false,
}
local ScriptAPI = {}
local ActiveTargets = {
    Mining = nil,
    Combat = nil
}
local function RedeemAllCodes()
    if not Remotes.RedeemCode then
        Window:Notify("Error", "RedeemCode remote not found!", 5)
        return
    end

    local codes = {
        "200K!", "100K!", "40KLIKES", "20KLIKES", "15KLIKES",
        "10KLIKES", "5KLIKES", "BETARELEASE!", "POSTRELEASEQNA"
    }
    for _, code in ipairs(codes) do
        task.spawn(function()
            local success, err = pcall(function()
                Remotes.RedeemCode:InvokeServer(code)
            end)
            if not success then
                warn("Failed to redeem code: " .. code .. " - " .. err)
            end
        end)
        task.wait(0.3) -- Slight delay for smoothness
    end
    Window:Notify("Success", "All codes redeemed!", 3)
end

-- ===================== AutoMine =====================
local function InitializeAutoMine()
    ScriptAPI.GetRockTypes = function()
        local rockTypes = {}
        local seen = {}
        local rocksFolder = Workspace:FindFirstChild("Rocks")

        if rocksFolder then
            for _, category in ipairs(rocksFolder:GetChildren()) do
                for _, child in ipairs(category:GetChildren()) do
                    if child.Name == "SpawnLocation" then
                        for _, model in ipairs(child:GetChildren()) do
                            if model:IsA("Model") and model:FindFirstChild("Hitbox") and not seen[model.Name] then
                                seen[model.Name] = true
                                table.insert(rockTypes, model.Name)
                            end
                        end
                    elseif child:IsA("Model") and child:FindFirstChild("Hitbox") and not seen[child.Name] then
                        seen[child.Name] = true
                        table.insert(rockTypes, child.Name)
                    end
                end
            end
        end
        table.sort(rockTypes)
        return rockTypes
    end
    local function FindNearestRock(maxDist)
        local char = LocalPlayer.Character
        if not char or not char:FindFirstChild("HumanoidRootPart") then return nil end

        local root = char.HumanoidRootPart
        local closestRock = nil
        local bestDist = maxDist or 15
        local rocksFolder = Workspace:FindFirstChild("Rocks")
        if not rocksFolder then return nil end
        for _, descendant in ipairs(rocksFolder:GetDescendants()) do
            if descendant.Name == "Hitbox" and descendant:IsA("BasePart") and descendant.Parent and descendant.Parent.Name == Config.MineTarget then
                local infoFrame = descendant.Parent:FindFirstChild("infoFrame")
                local hpText = infoFrame and infoFrame:FindFirstChild("Frame") and infoFrame.Frame:FindFirstChild("rockHP") and infoFrame.Frame.rockHP.Text

                local isValid = true
                if hpText then
                    local hp = tonumber(hpText:match("^(%d+)"))
                    if not hp or hp <= 0 then isValid = false end
                end
                if isValid then
                    local dist = (descendant.Position - root.Position).Magnitude
                    if dist < bestDist then
                        closestRock = descendant
                        bestDist = dist
                    end
                end
            end
        end
        return closestRock
    end
    task.spawn(function()
        while true do
            task.wait(0.05) -- Smoother loop
            local char = LocalPlayer.Character
            local root = char and char:FindFirstChild("HumanoidRootPart")
            local humanoid = char and char:FindFirstChild("Humanoid")
            if Config.AutoMine and Remotes.ToolActivated and root and humanoid then
                local pickaxe = char:FindFirstChild("Pickaxe")
                if not pickaxe then
                    local backpackPick = LocalPlayer.Backpack:FindFirstChild("Pickaxe")
                    if backpackPick then
                        humanoid:EquipTool(backpackPick)
                        task.wait(0.2) -- Delay for equip
                    end
                end
                local targetValid = false
                if ActiveTargets.Mining and ActiveTargets.Mining.Parent and ActiveTargets.Mining.Parent.Name == Config.MineTarget then
                    local infoFrame = ActiveTargets.Mining.Parent:FindFirstChild("infoFrame")
                    local hpText = infoFrame and infoFrame:FindFirstChild("Frame") and infoFrame.Frame:FindFirstChild("rockHP") and infoFrame.Frame.rockHP.Text
                    if hpText then
                        local hp = tonumber(hpText:match("^(%d+)"))
                        if hp and hp > 0 then targetValid = true end
                    else
                        targetValid = true
                    end
                end
                if not targetValid then ActiveTargets.Mining = nil end
                if not ActiveTargets.Mining then
                    ActiveTargets.Mining = FindNearestRock(500)
                end
                if pickaxe and ActiveTargets.Mining and humanoid.Health > 0 and ActiveTargets.Mining.Parent then
                    local dist = (root.Position - ActiveTargets.Mining.Position).Magnitude
                    if dist <= 15 then
                        Remotes.ToolActivated:InvokeServer("Pickaxe")
                    end
                end
            else
                ActiveTargets.Mining = nil
            end
        end
    end)
    RunService.Heartbeat:Connect(function(delta)
        local char = LocalPlayer.Character
        local root = char and char:FindFirstChild("HumanoidRootPart")

        if Config.AutoMine and ActiveTargets.Mining and ActiveTargets.Mining.Parent and root then
            root.Anchored = false
            root.AssemblyLinearVelocity = Vector3.zero
            root.AssemblyAngularVelocity = Vector3.zero

            local targetPos = ActiveTargets.Mining.Position
            root.CFrame = CFrame.lookAt(targetPos + Vector3.new(5, 0, 0), targetPos)
        end
    end)
end

-- ===================== AutoRun =====================
local function InitializeAutoRun()
    task.spawn(function()
        while true do
            task.wait(0.1)
            if Config.AutoRun and Remotes.Run then
                local char = LocalPlayer.Character
                if char and char:FindFirstChild("Humanoid") and char.Humanoid.Health > 0 then
                    Remotes.Run:InvokeServer()
                end
            end
        end
    end)
end

-- ===================== Combat =====================
local function InitializeCombat()
    local isBlocking = false
    ScriptAPI.GetMobTypes = function()
        local mobs = {}
        local seen = {}
        local living = Workspace:FindFirstChild("Living")

        if living then
            for _, model in ipairs(living:GetChildren()) do
                if model:IsA("Model") and model:FindFirstChild("Humanoid") and not model:FindFirstChild("RaceFolder") and not model:FindFirstChild("Animate") then
                    local name = model.Name:gsub("%d+$", "")
                    if not seen[name] then
                        seen[name] = true
                        table.insert(mobs, name)
                    end
                end
            end
        end
        table.sort(mobs)
        return mobs
    end
    local function FindTarget(maxDist)
        local char = LocalPlayer.Character
        if not char or not char:FindFirstChild("HumanoidRootPart") then return nil end

        local root = char.HumanoidRootPart
        local bestTarget = nil
        local bestDist = maxDist or 100

        local living = Workspace:FindFirstChild("Living")
        if not living then return nil end
        for _, mob in ipairs(living:GetChildren()) do
            if mob:IsA("Model") and mob:FindFirstChild("Humanoid") then
                local cleanName = mob.Name:gsub("%d+$", "")

                if Config.AttackTargets[cleanName]
                   and not mob:FindFirstChild("RaceFolder")
                   and not mob:FindFirstChild("Animate")
                   and mob.Humanoid.Health > 0
                   and mob:FindFirstChild("HumanoidRootPart") then

                    local mobRoot = mob.HumanoidRootPart
                    local dist = (mobRoot.Position - root.Position).Magnitude
                    if dist < bestDist then
                        bestTarget = mob
                        bestDist = dist
                    end
                end
            end
        end
        return bestTarget
    end
    task.spawn(function()
        while true do
            task.wait(0.05) -- Smoother
            local char = LocalPlayer.Character
            local root = char and char:FindFirstChild("HumanoidRootPart")

            if Config.AutoAttack and Remotes.ToolActivated and root and char:FindFirstChild("Humanoid") then
                local weapon = char:FindFirstChildWhichIsA("Tool")
                if not weapon or weapon.Name == "Pickaxe" or weapon.Name == "Hammer" then
                    for _, tool in ipairs(LocalPlayer.Backpack:GetChildren()) do
                        if tool:IsA("Tool") and tool.Name ~= "Pickaxe" and tool.Name ~= "Hammer" then
                            char.Humanoid:EquipTool(tool)
                            task.wait(0.2)
                            weapon = tool
                            break
                        end
                    end
                end
                local targetValid = false
                if ActiveTargets.Combat and ActiveTargets.Combat.Parent and ActiveTargets.Combat:FindFirstChild("Humanoid") then
                    local name = ActiveTargets.Combat.Name:gsub("%d+$", "")
                    if ActiveTargets.Combat.Humanoid.Health > 0 and Config.AttackTargets[name] then
                        targetValid = true
                    end
                end
                if not targetValid then
                    ActiveTargets.Combat = nil
                    if isBlocking then
                        Remotes.StopBlock:InvokeServer()
                        isBlocking = false
                    end
                end
                if not ActiveTargets.Combat then
                    ActiveTargets.Combat = FindTarget(500)
                end
                local target = ActiveTargets.Combat
                if weapon and target and char.Humanoid.Health > 0 and target.Parent then
                    local shouldBlock = false
                    if Config.AutoParry then
                        local status = target:FindFirstChild("Status")
                        local attacking = status and status:FindFirstChild("Attacking")
                        if attacking and attacking.Value == true then
                            shouldBlock = true
                        end
                    end
                    if shouldBlock then
                        if not isBlocking then
                            Remotes.StartBlock:InvokeServer()
                            isBlocking = true
                        end
                    else
                        if isBlocking then
                            Remotes.StopBlock:InvokeServer()
                            isBlocking = false
                        end

                        local targetRoot = target:FindFirstChild("HumanoidRootPart")
                        if targetRoot and (root.Position - targetRoot.Position).Magnitude <= 15 then
                            Remotes.ToolActivated:InvokeServer("Weapon")
                        end
                    end
                end
            else
                ActiveTargets.Combat = nil
                if isBlocking then
                    pcall(function() Remotes.StopBlock:InvokeServer() end)
                    isBlocking = false
                end
            end
        end
    end)
    RunService.Heartbeat:Connect(function(delta)
        local char = LocalPlayer.Character
        local root = char and char:FindFirstChild("HumanoidRootPart")

        if Config.AutoAttack and ActiveTargets.Combat and ActiveTargets.Combat.Parent and root then
            local targetRoot = ActiveTargets.Combat:FindFirstChild("HumanoidRootPart")
            if targetRoot then
                root.Anchored = false
                root.AssemblyLinearVelocity = Vector3.zero
                root.AssemblyAngularVelocity = Vector3.zero
                root.CFrame = CFrame.lookAt((targetRoot.CFrame * CFrame.new(0, 0, 3)).Position, targetRoot.Position)
            end
        end
    end)
end

-- ===================== Forge =====================
local function InitializeForge()
    local function InstantForge(ores, itemType, callback)
        local prox = Workspace:FindFirstChild("Proximity")
        local forgeModel = prox and prox:FindFirstChild("Forge")

        if not Remotes.ChangeSequence or not Remotes.StartForge or not Remotes.Forge or not forgeModel then
            if callback then callback("Error", "Failed to find necessary remotes or Forge model.", 5) end
            return
        end
        if not itemType then itemType = "Weapon" end
        if callback then callback("Forge", "Starting Instant Forge... Please do not close the window.", 5) end
        Remotes.Forge:InvokeServer(forgeModel)
        task.wait(0.1)
        Remotes.StartForge:InvokeServer(forgeModel)
        task.wait(0.2)

        Remotes.ChangeSequence:InvokeServer(unpack({
            "Melt",
            {
                FastForge = false,
                ItemType = itemType,
                Ores = ores
            }
        }))

        task.wait(0.5)
        Remotes.ChangeSequence:InvokeServer("Pour", { ClientTime = Workspace:GetServerTimeNow() })

        task.wait(0.5)
        Remotes.ChangeSequence:InvokeServer("Hammer", { ClientTime = Workspace:GetServerTimeNow() })

        task.wait(0.5)
        task.spawn(function()
            Remotes.ChangeSequence:InvokeServer("Water", { ClientTime = Workspace:GetServerTimeNow() })
        end)

        task.wait(0.5)
        Remotes.ChangeSequence:InvokeServer("Showcase", {})

        if callback then callback("Success", "Instant Forge Completed! You can close the window.", 5) end
    end
    local function GetAvailableOres()
        local oreData = {}
        local playerGui = LocalPlayer:FindFirstChild("PlayerGui")
        if not playerGui then return {} end
        local oreFrame = playerGui:FindFirstChild("Forge")
            and playerGui.Forge:FindFirstChild("OreSelect")
            and playerGui.Forge.OreSelect:FindFirstChild("OresFrame")
            and playerGui.Forge.OreSelect.OresFrame:FindFirstChild("Frame")
            and playerGui.Forge.OreSelect.OresFrame.Frame:FindFirstChild("Background")
        if not oreFrame then return {} end
        for _, child in ipairs(oreFrame:GetChildren()) do
            local main = child:FindFirstChild("Main")
            local quantityLabel = main and main:FindFirstChild("Quantity")

            if quantityLabel then
                local text = quantityLabel.Text or (quantityLabel:FindFirstChild("Text") and quantityLabel.Text.Text)
                if text then
                    local qty = tonumber(text:match("%d+"))
                    if qty then
                        oreData[child.Name] = qty
                    end
                end
            end
        end
        return oreData
    end
    ScriptAPI.InstantForge = InstantForge
    ScriptAPI.GetAvailableOres = GetAvailableOres
end

-- ===================== Movement =====================
local function InitializeMovement()
    UserInputService.InputBegan:Connect(function(input, gameProcessed)
        if gameProcessed then return end
        if Config.ClickTeleport and input.UserInputType == Enum.UserInputType.MouseButton1 and UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
            local char = LocalPlayer.Character
            local root = char and char:FindFirstChild("HumanoidRootPart")
            local mouse = LocalPlayer:GetMouse()

            if root and mouse.Hit then
                root.CFrame = CFrame.new(mouse.Hit.Position + Vector3.new(0, 3, 0))
            end
        end
    end)
    local bg, bv
    local flying = false
    local function stopFly()
        flying = false
        if bg then bg:Destroy(); bg = nil end
        if bv then bv:Destroy(); bv = nil end

        local char = LocalPlayer.Character
        local humanoid = char and char:FindFirstChild("Humanoid")
        if humanoid then humanoid.PlatformStand = false end
    end
    local function startFly()
        local char = LocalPlayer.Character
        local root = char and char:FindFirstChild("HumanoidRootPart")
        local humanoid = char and char:FindFirstChild("Humanoid")

        if not root or not humanoid then return end

        flying = true
        humanoid.PlatformStand = true

        bg = Instance.new("BodyGyro", root)
        bg.P = 90000
        bg.maxTorque = Vector3.new(9e9, 9e9, 9e9)
        bg.CFrame = root.CFrame

        bv = Instance.new("BodyVelocity", root)
        bv.Velocity = Vector3.zero
        bv.MaxForce = Vector3.new(9e9, 9e9, 9e9)
        task.spawn(function()
            while flying do
                local cam = Workspace.CurrentCamera
                if cam then
                    local direction = Vector3.zero
                    if UserInputService:IsKeyDown(Enum.KeyCode.W) then direction = direction + cam.CFrame.LookVector end
                    if UserInputService:IsKeyDown(Enum.KeyCode.S) then direction = direction - cam.CFrame.LookVector end
                    if UserInputService:IsKeyDown(Enum.KeyCode.A) then direction = direction - cam.CFrame.RightVector end
                    if UserInputService:IsKeyDown(Enum.KeyCode.D) then direction = direction + cam.CFrame.RightVector end

                    if direction.Magnitude > 0 then
                        bv.Velocity = direction.Unit * Config.FlySpeed
                    else
                        bv.Velocity = Vector3.zero
                    end
                    bg.CFrame = cam.CFrame
                    RunService.RenderStepped:Wait()
                else
                    break
                end
            end
            stopFly()
        end)
    end
    task.spawn(function()
        while true do
            task.wait(0.2)
            if Config.InfiniteFly then
                if not flying and LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart") then
                    startFly()
                end
            else
                if flying then
                    stopFly()
                end
            end
        end
    end)
    LocalPlayer.CharacterAdded:Connect(function()
        if flying then stopFly() end
    end)
end

-- Initialize systems
InitializeAutoMine()
InitializeAutoRun()
InitializeCombat()
InitializeForge()
InitializeMovement()

-- ===================== GUI Setup with Premium Feel =====================
local InfoTab = Window:Tab({ Title = "Information", Icon = "info" })
InfoTab:Paragraph({
    Title = "Welcome to DYHUB Premium",
    Desc = "Enhanced features for smooth gameplay. Auto Mine and Instant Forge preserved and optimized.",
    Image = "rbxassetid://104487529937663",
    ImageSize = 50,
    Locked = false
})
local MainTab = Window:Tab({ Title = "Main", Icon = "rocket" })
local PlayerTab = Window:Tab({ Title = "Player", Icon = "user" })
local TeleportTab = Window:Tab({ Title = "Teleport", Icon = "map" })
local ForgeTab = Window:Tab({ Title = "Forge", Icon = "anvil" })
local CombatTab = Window:Tab({ Title = "Combat", Icon = "sword" })

-- ========== Main Tab ==========
MainTab:Section({ Title = "Farming", Icon = "tractor" })
MainTab:Toggle({Title="Auto Mine", Value=Config.AutoMine, Callback=function(v) Config.AutoMine = v end})
local RockList = {}
local RockDropdown

-- helper to compare two lists (shallow)
local function listsEqual(a, b)
    if not a and not b then return true end
    a = a or {}
    b = b or {}
    if #a ~= #b then return false end
    for i = 1, #a do
        if a[i] ~= b[i] then return false end
    end
    return true
end

-- refresh rocks periodically (refresh whenever content changes)
task.spawn(function()
    while true do
        if ScriptAPI.GetRockTypes then
            local newRocks = ScriptAPI.GetRockTypes()
            table.sort(newRocks)
            if not listsEqual(newRocks, RockList) then
                RockList = newRocks
                if RockDropdown then
                    RockDropdown:Refresh(RockList)
                end
            end
        end
        task.wait(3) -- Reduced frequency for performance
    end
end)

RockDropdown = MainTab:Dropdown({
    Title = "Target Mine",
    Values = RockList,
    Multi = false,
    Callback = function(value)
        Config.MineTarget = value
    end
})
RockDropdown:Refresh(RockList)

MainTab:Section({ Title = "Codes", Icon = "gift" })
MainTab:Button({
    Title = "Redeem All Codes",
    Callback = RedeemAllCodes
})

-- ========== Player Tab ==========
PlayerTab:Section({ Title = "Movement", Icon = "running" })
PlayerTab:Toggle({Title="Auto Run", Value=Config.AutoRun, Callback=function(v) Config.AutoRun = v end})
PlayerTab:Toggle({Title="Infinite Fly (PC ONLY)", Value=Config.InfiniteFly, Callback=function(v) Config.InfiniteFly = v end})
PlayerTab:Slider({
    Title = "Fly Speed",
    Min = 10,
    Max = 200,
    Value = Config.FlySpeed,
    Callback = function(v) Config.FlySpeed = v end
})
PlayerTab:Toggle({Title="Click TP (Ctrl + Click)", Value=Config.ClickTeleport, Callback=function(v) Config.ClickTeleport = v end})

-- ========== Combat Tab (fixed) ==========
CombatTab:Section({ Title = "Combat Features", Icon = "swords" })

local MobList = {}
local SelectedMob = nil

local MobDropdown = CombatTab:Dropdown({
    Title = "Select Mob",
    Values = MobList,
    Multi = false,
    Callback = function(v)
        SelectedMob = v
        -- update AttackTargets map for current selection
        for k,_ in pairs(Config.AttackTargets) do Config.AttackTargets[k] = nil end
        if v then Config.AttackTargets[v] = true end
    end
})

CombatTab:Toggle({Title = "Auto Attack", Value = Config.AutoAttack, Callback = function(v) Config.AutoAttack = v end})
CombatTab:Toggle({Title = "Auto Parry", Value = Config.AutoParry, Callback = function(v) Config.AutoParry = v end})

-- Auto refresh mob list
task.spawn(function()
    while task.wait(1) do
        local NewList = {}
        local living = workspace:FindFirstChild("Living")
        if living then
            for _, mob in pairs(living:GetChildren()) do
                if mob:IsA("Model") and mob:FindFirstChild("Humanoid") and mob.Humanoid.Health > 0 then
                    table.insert(NewList, mob.Name:gsub("%d+$", ""))
                end
            end
        end

        table.sort(NewList)
        -- remove duplicates
        local unique = {}
        for _, name in ipairs(NewList) do
            if not (unique[#unique] == name) then table.insert(unique, name) end
        end

        if #unique ~= #MobList then
            MobList = unique
            if MobDropdown then MobDropdown:Refresh(MobList) end
        end
    end
end)

-- Auto attack loop (uses Config.AutoAttack and SelectedMob)
task.spawn(function()
    while task.wait(0.1) do
        if Config.AutoAttack and SelectedMob then
            local mob = nil
            -- try to find an instanced mob matching SelectedMob
            local living = workspace:FindFirstChild("Living")
            if living then
                for _, m in ipairs(living:GetChildren()) do
                    if m.Name:find(SelectedMob) and m:FindFirstChild("HumanoidRootPart") then
                        mob = m
                        break
                    end
                end
            end
            local char = LocalPlayer.Character
            if mob and mob:FindFirstChild("HumanoidRootPart") and char and char:FindFirstChild("HumanoidRootPart") then
                pcall(function()
                    char:PivotTo(mob.HumanoidRootPart.CFrame * CFrame.new(0, 0, 3))
                    -- attempt server-legal attack
                    if Remotes.ToolActivated then
                        Remotes.ToolActivated:InvokeServer("Weapon")
                    end
                end)
            end
        end
    end
end)

-- ========== Forge Tab (fixed) ==========
ForgeTab:Section({ Title = "Instant Forge", Icon = "pickaxe" })
ForgeTab:Paragraph({
    Title = "WARNING",
    Desc = "• Use Instant Forge responsibly. Quit and reopen before manual forging.\n• Select ores and amounts for instant creation.",
    Image = "rbxassetid://104487529937663",
    ImageSize = 45,
    Locked = false
})

local OreList = {}
local SelectedOre = nil
local OreDropdown = ForgeTab:Dropdown({
    Title = "Select Ore",
    Values = OreList,
    Multi = false,
    Callback = function(v)
        SelectedOre = v
    end
})

ForgeTab:Button({ Title = "Instant Forge", Callback = function()
    if not SelectedOre then Window:Notify("Error","No ore selected.",4); return end
    -- build ores table expected by InstantForge
    local ores = {}
    ores[SelectedOre] = 1 -- default 1 quantity; advanced UI can be added to select amount
    if ScriptAPI.InstantForge then
        ScriptAPI.InstantForge(ores, Config.ForgeItemType, function(t, msg, dur)
            Window:Notify(t, msg, dur or 3)
        end)
    else
        Window:Notify("Error","InstantForge API not available.",4)
    end
end })

-- Auto refresh ores
task.spawn(function()
    while task.wait(2) do
        local NewList = {}
        if ScriptAPI.GetAvailableOres then
            local ores = ScriptAPI.GetAvailableOres()
            for name, qty in pairs(ores) do
                table.insert(NewList, name .. " (" .. tostring(qty) .. ")")
            end
        end
        table.sort(NewList)
        if #NewList ~= #OreList then
            OreList = NewList
            if OreDropdown then OreDropdown:Refresh(OreList) end
        end
    end
end)

-- ========== Teleport Tab (fixed) ==========
TeleportTab:Section({ Title = "Teleport Locations", Icon = "map" })

local TeleportList = {}
local SelectedTeleport = nil
local TeleportDropdown = TeleportTab:Dropdown({
    Title = "Select Location",
    Values = TeleportList,
    Multi = false,
    Callback = function(v)
        SelectedTeleport = v
    end
})

TeleportTab:Button({ Title = "Teleport Now", Callback = function()
    if SelectedTeleport then
        local name = SelectedTeleport
        -- If the dropdown shows names with extra info (like "Name (x)"), try to extract clean name
        local clean = tostring(name):match("^[^%(]+") or tostring(name)
        clean = clean:gsub("%s+$", "")
        local Point = workspace:FindFirstChild(clean)
        if not Point then
            -- fallback search for Part named containing the clean name
            for _, v in pairs(workspace:GetChildren()) do
                if v:IsA("BasePart") and v.Name:match(clean) then Point = v; break end
            end
        end
        if Point and Point:IsA("BasePart") then
            local char = game.Players.LocalPlayer.Character
            if char and char:FindFirstChild("HumanoidRootPart") then
                char:PivotTo(Point.CFrame + Vector3.new(0, 3, 0))
            end
        else
            Window:Notify("Error", "Teleport point not found: " .. tostring(clean), 4)
        end
    else
        Window:Notify("Info", "No teleport selected.", 3)
    end
end })

-- Auto refresh teleport list
task.spawn(function()
    while task.wait(1) do
        local NewList = {}
        for _, v in pairs(workspace:GetChildren()) do
            if v:IsA("BasePart") and v.Name:match("TP") then
                table.insert(NewList, v.Name)
            elseif v:IsA("Model") then
                -- also allow models named TP_<name> or containing TP
                if v.Name:match("TP") then table.insert(NewList, v.Name) end
            end
        end
        table.sort(NewList)
        if #NewList ~= #TeleportList then
            TeleportList = NewList
            if TeleportDropdown then TeleportDropdown:Refresh(TeleportList) end
        end
    end
end)

-- ========== Game Data Callback for WindUI ==========
Library = Library or {} -- ensure Library exists to avoid errors if WindUI doesn't provide it
if Library.SetGameDataCallback then
    Library.SetGameDataCallback(function()
        local gui = LocalPlayer:FindFirstChild("PlayerGui")
        local level = 0
        local gold = 0
        local inventory = {}
        if gui then
            local hud = gui:FindFirstChild("Main") and gui.Main:FindFirstChild("Screen") and gui.Main.Screen:FindFirstChild("Hud")
            if hud then
                local lvlLbl = hud:FindFirstChild("Level")
                if lvlLbl then level = tonumber(lvlLbl.Text:match("%d+")) or 0 end

                local goldLbl = hud:FindFirstChild("Gold")
                if goldLbl then gold = tonumber(goldLbl.Text:gsub("[$,]", "")) or goldLbl.Text end
            end

            local stash = gui:FindFirstChild("Menu") and gui.Menu:FindFirstChild("Frame") and gui.Menu.Frame:FindFirstChild("Frame")
                and gui.Menu.Frame.Frame:FindFirstChild("Menus") and gui.Menu.Frame.Frame.Menus:FindFirstChild("Stash")
                and gui.Menu.Frame.Frame.Menus.Stash:FindFirstChild("Background")

            if stash then
                for _, itemFrame in ipairs(stash:GetChildren()) do
                    local main = itemFrame:FindFirstChild("Main")
                    if main then
                        local nameLbl = main:FindFirstChild("ItemName")
                        local qtyLbl = main:FindFirstChild("Quantity")
                        if nameLbl and qtyLbl then
                            local iName = nameLbl.Text
                            local iQty = qtyLbl.Text
                            if iName ~= "" and iQty ~= "" then
                                inventory[iName] = tonumber(iQty:match("%d+")) or iQty
                            end
                        end
                    end
                end
            end
        end
        local features = {}
        for k, v in pairs(Config) do features[k] = v end
        return {
            level = level,
            gold = gold,
            inventory = inventory,
            timestamp = os.time(),
            features = features,
        }
    end)
end

-- Final: notify user that GUI is ready
Window:Notify("Ready", "DYHUB UI loaded and tabs initialized.", 4)
-- End of file
